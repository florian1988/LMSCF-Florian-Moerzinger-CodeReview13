<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\ HttpFoundation\Request;
use Symfony\ Component\HttpFoundation\Response;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\Eventlist;

class EventController extends AbstractController
{
    /**
     * @Route("/event", name="event_page")
     */
    public function index()
    {
        $events = $this->getDoctrine()->getRepository('App:Eventlist')->findAll();
        return $this->render('event/index.html.twig',array('events'=>$events));
    }
        /**
    * @Route("/create", name="create_page")
    */
   public  function createAction(Request $request)
   {
       $event = new Eventlist;

       $form = $this->createFormBuilder($event)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('date', DateTimeType::class, array('attr' => array('class'=> 'form-inline','style'=>'margin-bottom:15px')))
          ->add('Description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('contactmail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('phonenumber', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('zipcode', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('eventurl', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('eventtype', ChoiceType::class, array('choices'=>array('Music'=>'Music', 'Sport'=>'Sport', 'Movie'=>'Movie', 'Theater' => 'Theater'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
          ->add('save', SubmitType::class, array('label'=> 'Create Eventlist', 'attr' => array('class'=> 'btn-light btn-lg', 'style'=>'margin:15px')))
          ->getForm();

       $form->handleRequest($request);

      if($form->isSubmitted() && $form->isValid()){
      //fetching data

            $name = $form['name']->getData();
            $date = $form['date']->getData();
            $Description = $form['Description']->getData();
            $image = $form['image']->getData();
            $capacity = $form['capacity']->getData();
            $contactmail = $form['contactmail']->getData();
            $phonenumber = $form['phonenumber']->getData();
            $address = $form['address']->getData();
            $zipcode = $form['zipcode']->getData();
            $city = $form['city']->getData();
            $eventurl = $form['eventurl']->getData();
            $eventtype = $form['eventtype']->getData();
            
          $event->setName($name);
          $event->setDate($date);
          $event->setDescription($Description);
          $event->setImage($image);
          $event->setCapacity($capacity);
          $event->setContactMail($contactmail);
          $event->setPhoneNumber($phonenumber);
          $event->setAddress($address);
          $event->setZipCode($zipcode);
          $event->setCity($city);
          $event->setEventUrl($eventurl);
          $event->setEventType($eventtype);

          $em = $this->getDoctrine()->getManager();
          $em->persist($event);
          $em->flush();
          $this->addFlash(
                 'notice',
                 'Eventlist Added'
                 );
          return $this->redirectToRoute('event_page');
      }
      return  $this->render('event/create.html.twig',array('form' => $form->createView()));
   }

    /**
    * @Route("/edit/{id}", name="edit_page")
    */
   public  function editAction($id, Request $request)
   {

      $event = $this->getDoctrine()->getRepository('App:Eventlist')->find($id);

        $event->setName($event->getName());
        $event->setDate($event->getDate());
        $event->setDescription($event->getDescription());
        $event->setImage($event->getImage());
        $event->setCapacity($event->getCapacity());
        $event->setContactMail($event->getContactMail());
        $event->setPhoneNumber($event->getPhoneNumber());
        $event->setAddress($event->getAddress());
        $event->setZipCode($event->getZipCode());
        $event->setCity($event->getCity());
        $event->setEventUrl($event->getEventUrl());
        $event->setEventType($event->getEventType());

        $form = $this->createFormBuilder($event)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('date', DateTimeType::class, array('attr' => array('class'=> 'form-inline','style'=>'margin-bottom:15px')))
          ->add('Description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('contactmail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('phonenumber', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('zipcode', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('eventurl', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('eventtype', ChoiceType::class, array('choices'=>array('Music'=>'Music', 'Sport'=>'Sport', 'Movie'=>'Movie', 'Theater' => 'Theater'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
          ->add('save', SubmitType::class, array('label'=> 'Create Eventlist', 'attr' => array('class'=> 'btn-light btn-lg', 'style'=>'margin:15px')))
          ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){

            $name = $form['name']->getData();
            $date = $form['date']->getData();
            $Description = $form['Description']->getData();
            $image = $form['image']->getData();
            $capacity = $form['capacity']->getData();
            $contactmail = $form['contactmail']->getData();
            $phonenumber = $form['phonenumber']->getData();
            $address = $form['address']->getData();
            $zipcode = $form['zipcode']->getData();
            $city = $form['city']->getData();
            $eventurl = $form['eventurl']->getData();
            $eventtype = $form['eventtype']->getData();

            $em = $this->getDoctrine()->getManager();
            $event = $em->getRepository('App:Eventlist')->find($id);

            $event->setName($name);
            $event->setDate($date);
            $event->setDescription($Description);
            $event->setImage($image);
            $event->setCapacity($capacity);
            $event->setContactMail($contactmail);
            $event->setPhoneNumber($phonenumber);
            $event->setAddress($address);
            $event->setZipCode($zipcode);
            $event->setCity($city);
            $event->setEventUrl($eventurl);
            $event->setEventType($eventtype);

            $em->flush();
            $this->addFlash(
                   'notice',
                   'Eventlist Updated'
                   );
            return $this->redirectToRoute('event_page');
      }
      return  $this->render('event/edit.html.twig', array('event' => $event, 'form' => $form->createView()));
   }

    /**
    * @Route("/details/{id}", name="details_page")
    */
   public  function detailsAction($id)
   {
        $event = $this->getDoctrine()->getRepository('App:Eventlist')->find($id);
        return $this->render('event/details.html.twig', array('event' => $event));
   }

       /**
    * @Route("/delete/{id}", name="delete_page")
    */
   public function deleteAction($id)
   {
      $em = $this->getDoctrine()->getManager();
      $event = $em->getRepository('App:Eventlist')->find($id);
      $em->remove($event);
      $em->flush();
      $this->addFlash(
        'notice',
        'Eventlist Removed'
      );
      return $this->redirectToRoute('event_page');
   }
}

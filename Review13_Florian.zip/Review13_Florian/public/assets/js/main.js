$(document).ready(function(){
	$('body').show(1000);
})
